# 문제5-3. 고차함수 연습
# 1. 함수 func와 두 개의 숫자를 인수로 받고 func(x, y)호출 결과를 반환하는
# 함수 do_operation(func, x, y)를 작성하시오.
# • add(x, y), sub(x, y) 함수를 이용하여 테스트 하시오.
# 예:
# def add(a, b):
# return a + b
# result = do_operation(add, 2, 3)
# print(result) # 5
# 2. add()와 sub()를 lambda 함수로 정의하여 사용해 보시오.


def do_operation(func, x, y):
    return func(x, y)


#1. 일반 함수
def add(a, b):
    return a + b
def sub(a, b):
    return a - b

#2. lambda함수
add_lambda = lambda a, b: a + b
sub_lambda = lambda a, b: a - b


result = do_operation(add, 3, 6)
print(f"add(): {result}")
result = do_operation(sub, 3, 6)
print(f"sub(): {result}")
result = do_operation(add_lambda, 3, 6)
print(f"add_lambda(): {result}")
result = do_operation(sub_lambda, 3, 6)
print(f"sub_lambda(): {result}")