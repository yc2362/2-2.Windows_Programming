# 문제 4-1
#
# • 사용자가 요청한 파일을 읽어서
#     1. 라인번호를 붙여 출력하는 프로그램을 작성하시오
#     2. 라인번호를 붙여 ***.sav 형식의 이름으로 저장하는 프로그램을 작성하시오
# 예
#     Opens a file for reading only in binary. -> 1 Opens a file for reading only in binary.
#     The file pointer is placed. -> 2 The file pointer is placed.
#     This is the default mode. -> 3 This is the default mode.
#
# • 사용자가 요청한 파일이 없는 경우 크래시되지 않고 다른 파일명을 입력하게 하거나 종료되도록 하시오.
#     • FileNotFoundError 처리

# 테스트용 파일 생성
# with open("memo.txt", "w") as file:
#     file.write("Opens a file for reading only in binary.\n"
#         +"The file pointer is placed.\n"
#         +"This is the default mode."
#     )



# 파일 존재 여부 확인 함수
def file_exists(file_name):
    try:
        with open(file_name, "r"):
            pass
    # 파일이 없으면 FileNotFoundError를 처리하여 False 반환
    except FileNotFoundError:
        return False
    return True


while True:
    print("="*40)
    # 파일명 입력 및 "end" 입력시 종료.
    if (result := input("파일이름 입력(종료시: end): ")) == "end":
        break
    # 입력 파일 존재 여부 검사. 없다면 세션 재실행
    if not file_exists(result):
        print("입력한 이름의 파일이 없습니다")
        continue

    with open(result, "r") as file:

        # 빈 파일 확인 후 읽기 위치 초기화. 빈 파일 이면 세션 재실행
        if file.read(1) == "":
            print("빈 파일입니다.")
            continue
        file.seek(0)

        # 원본 파일명을 바탕으로 .sav 저장 파일명 생성
        if not result.endswith(".sav"):
            # 원본 파일명에서 stem 추출후 저장 파일명 생성
            file_name = result.rsplit(".", 1)[0] + ".sav"
        else:
            # 원본 파일명 확장자가 .sav인 경우
            file_name = result + ".sav"

        # 저장 파일명 중복 확인 및 사용자 선택 처리
        option = "w"
        while file_exists(file_name):
            option = input(
                f"생성하려는 {file_name}이 이미 존재 합니다.\n"
                "[w] 덮어쓰기 / [1] 이름에 (1) 추가 / [그 외] 취소: "
            )
            if option == "1":
                file_name = file_name.rsplit(".",1)[0] + "(1).sav"
            else:
                break

        if option not in ("w", "1"):
            continue

        # 저장 파일 열기 및 줄 번호 초기화
        line_count = 0
        with open(file_name, "w") as sav:

            # 파일을 한 줄씩 읽으며 EOF(빈 문자열 반환)에 도달할 때까지 반복
            # 각 줄에 번호를 붙여 출력하고 파일에 저장
            while line := file.readline():
                line_count += 1
                line = str(line_count) + " " + line
                print(line, end = "" if line.endswith("\n") else "\n") # 마지막 줄의 개행 여부에 따라 화면 출력 보정
                sav.write(line)


print("종료")







# 함수 없이 해 보려 했는데 욕심을 다 구현하려니 깊이가 너무 더러워져서 포기
# while True:
#     print("="*40)
#     request = input("파일이름 입력(종료시: end): ")
#     if request == "end":
#         break
#     try:
#         line_count = 1
#         with open(request, "r") as file:
#
#             # 빈 파일 확인 후 읽기 위치 초기화
#             if file.read(1) == "":
#                 print("빈 파일입니다.")
#                 continue
#             file.seek(0)
#
#             # 원본 파일명에서 확장자 제거. 단, 입력 파일의 확장자가 .sav인 경우 유지.
#             if not request.endswith(".sav"):
#                 file_name = request.rsplit(".", 1)[0]
#             else:
#                 file_name = request
#
#             # 추가 파일 확장자 추가 및 열기
#             for mood in "xw":
#                 if line_count == 1:
#                     try:
#                         with open(file_name + ".sav", mood) as sav:
#
#                             # 파일을 한 줄씩 읽으며 EOF(빈 문자열 반환)에 도달할 때까지 반복
#                             # 각 줄에 번호를 붙여 출력하고 파일에 저장
#                             while line := file.readline():
#                                 line = str(line_count) + " " + line
#                                 print(line, end = "" if line.endswith("\n") else "\n") # 마지막 줄의 개행 여부에 따라 화면 출력 보정
#                                 sav.write(line)
#                                 line_count += 1
#                     except FileExistsError:
#                         mood_set = input(f"파일 {file_name}.sav 가 이미 있습니다.\n"
#                          f"덮어쓰기: 'w', 파일이름에 '(1)' 추가하기: '1', 취소: 'w', '1'제외 아무키")
#                         if mood_set == "1":
#                             file_name += "(1)"
#                         elif mood_set != "w":
#                             line_count = 0
#
#
#     # 파일이 존재하지 않는 경우 예외 처리
#     except FileNotFoundError:
#         print("입력한 이름의 파일이 없습니다")
#
# print("종료")