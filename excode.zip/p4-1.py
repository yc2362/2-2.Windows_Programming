# • 사용자가 요청한 파일을 읽어서
# 1. 라인번호를 붙여 출력하는 프로그램을 작성하시오
# 2. 라인번호를 붙여 ***.sav 형식의 이름으로 저장하는 프로그램
# 을 작성하시오

# 예
# Opens a file for reading only in binary. -> 1 Opens a file for reading only in binary.
# The file pointer is placed. -> 2 The file pointer is placed.
# This is the default mode. -> 3 This is the default mode.

# • 사용자가 요청한 파일이 없는 경우 크래시되지 않고 다른
# 파일명을 입력하게 하거나 종료되도록 하시오.
# • FileNotFoundError 처리

# 테스트용 파일 생성
with open("memo.txt", "w") as file:
    file.write("Opens a file for reading only in binary.\n"
        +"The file pointer is placed.\n"
        +"This is the default mode."
    )




while True:
    print("="*40)
    request = input("파일이름 입력(종료시: end): ")
    if request == "end":
        break
    try:
        line_count = 1
        with open(request, "r") as file:

            # 빈 파일 확인 후 읽기 위치 초기화
            if file.read(1) == "":
                print("빈 파일입니다.")
                continue
            file.seek(0)

            # 원본 파일명에서 확장자 제거
            file_name = request.rsplit(".", 1)[0]
            with open(file_name + ".sav", "w") as sav:

                # 각 줄에 번호를 붙여 출력하고 파일에 저장
                while line := file.readline():
                    line = str(line_count) + " " + line
                    print(f"{line}", end = "")
                    sav.write(line)
                    line_count += 1
                    last = line[-1]

        # 마지막 줄의 개행 여부에 따라 화면 출력 보정
        if last != "\n": print()

    # 파일이 존재하지 않는 경우 예외 처리
    except FileNotFoundError:
        print("입력한 이름의 파일이 없습니다")

print("종료")








