# 연습7-7 딕셔너리 사용
#
# • 학생들의 점수를 저장한 딕셔너리 scores를 이용해 아래 작업을 수행하시오.
#     • 각 학생별로 평균 점수를 계산하여 새로운 딕셔너리 averages를 생
#     성하고 출력하시오
#         예: { “Kim”: 80, “Lee”, 91, “Park”: 93}
#     • 평균 점수가 90점 이상인 학생이름을 리스트 names에 저장하고 출력하시오.
#         예: [“Lee”, “Park”]
#
#     scores = {
#         "Kim": [80, 90, 70],
#         "Lee": [100, 90, 85],
#         "Park": [95, 85, 100]
#     }



scores = {
    "Kim": [80, 90, 70],
    "Lee": [100, 90, 85],
    "Park": [95, 85, 100]
}
averages = {}
names = []
for name, scores_list in scores.items():
    averages[name] = sum(scores_list) / len(scores_list)
    if averages[name] >= 90:
        names.append(name)

print(averages)
print(names)