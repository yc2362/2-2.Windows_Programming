# 문제 3-1
# • 다음과 같은 함수 를 작성하시오
# • 함수명: calc
# • 인수: 가변 개수의 정수들이 나열되고, 마지막으로 연산을 나타내
# 는 부호(+, *)가 키워드 인수로 제공된다.
# • 인수들을 연산하여 결과를 반환한다
# • 실행 예
# • calc(1, 1, 4, op=‘+’) -> 1+1+4=6, 반환값 6
# • calc(1, 2, op=‘*’) -> 1*2=2, 반환값 2


def calc(*args, op):

    if op == "+":
        num = 0
        for i in args:
            num += i

    elif op == "*":
        num = 1
        for i in args:
            num *= i
    # print(F"{op.join(map(str,args))}={num}, 반환값 {num}")

    return num


# 과제조건 기계적 해석
print(F"1+4+3= 8, 반환값 {calc(1, 4, 3, op= "+")}")

# 일반화
calc_input = ["*",1,4,3]
result  = calc(*calc_input[1:], op= calc_input[0])
print(F"{calc_input[0].join(map(str, calc_input[1:]))}={result }, 반환값 {result}")

