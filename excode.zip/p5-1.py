# 문제5-1. 데코레이터 연습 1
# • 두수의 합을 반환하는 add(a, b)를 ‘a + b = (a+b)’를 반환하도
# 록 수정하는 데코레이터 deco_add() 를 작성하시오
# def deco_add(func):
# . . .
# @deco_add
# def add(a, b):
# return a + b
# print(add(2, 4)) # ‘2 + 4 = 6’ 출력



def deco_add(func):
    def wrapper(a, b):
        result = func(a, b)
        return f"{a} + {b} = {result}"
    return wrapper

@deco_add
def add(a, b):
    return a + b


print(add(2, 4)) # ‘2 + 4 = 6’ 출력