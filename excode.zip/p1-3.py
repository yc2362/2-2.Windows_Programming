# 연습문제 1-3: 수식계산
#
# • a=3, b=4, c=5 일 때 1/(1+𝑎/𝑏+𝑐)의 값은?
# • 2 차방정식의 계수가 a=1, b=1 c=-6 일 때 두 근은?
# • 반지름 r=5일 때 원의 면적은?
# • 𝛽 = 2.0, 𝑔 = 3.2 일때 𝛽𝑒^(−𝑔)의 값은?
# • x=0, 𝜇=1.5, 𝜌 =2.0 일 때 다음 식의 값은?
#   1 / √(2πρ) × e^((x - μ)² / (2ρ²))

a, b, c = map(int, input("정수 3개를 입력: ").split())


print(f"1/(1+a/b+c)")

print(f"이차항의 두 근: ",
    "-b/2/a - ((b/2/a)**2 - c/a)**0.5",
    "-b/2/a + ((b/2/a)**2 - c/a)**0.5",
    sep=''
)# 소수점 조절은 과함. 복소수에서 끝


r = int(input('반지름을 입력: '))
print(f'원의 넓이: {math.pi * r**2:.2f}')

beta, g = map(float, input('실수 β와 g를 입력: ').split())
print(f'βℯ^(-g): {beta*math.e**(-g)}')

x, u, p = map(float, input("실수 x와 μ와 양수ρ를 입력: ").split())
print( f'{(1 / math.sqrt(2*math.pi*p))
       * math.exp( (x-u)**2 / (2*p**2) ):.4f}'
       )