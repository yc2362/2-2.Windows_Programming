# 문제 2-6. 소수 찾기
#
# • 1과 100사이의 자연수 n이 소수인지를 판별하여 소수인 경우에만 다음과 같이 출력하시오.
# 출력 예
#   ‘3은 소수입니다’
#   ‘5는 소수입니다
#   …


# n = 89
# i=1
# if n > 1:
#     while True:
#         i += 1
#         if i**2 > n:
#             print(f"{n}은 소수입니다.")
#             break
#         elif n%i == 0:
#             break


n = 67
if n > 1:
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            break
    else:
        print(f"{n}은 소수입니다.")
