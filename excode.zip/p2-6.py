# 문제 2-6. 소수 찾기
#
# • 1과 100사이의 자연수 n이 소수인지를 판별하여 소수인 경우에만 다음과 같이 출력하시오.
# 출력 예
#   ‘3은 소수입니다’
#   ‘5는 소수입니다
#   …



# **소수인 경우에만 출력**
# **소수인 경우에만 출력**
n = 2
if n > 1:
    # 약수를 제곱근까지만 검사
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            break
    else: # break 없이 반복이 종료되면 소수
        particle = "은" if n % 10 in (1, 3, 7) else "는"
        print(f"{n}{particle} 소수입니다.")



# [대안 풀이] while문으로 약수의 제곱이 n을 초과할 때까지 검사
# n = 89
# if n > 1:
#     i=1
#     while True:
#         i += 1
#         if i**2 > n:
#             print(f"{n}은 소수입니다.")
#             break
#         elif n%i == 0:
#             break