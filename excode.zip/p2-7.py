# 연습문제 2-7. 행맨 게임
#
# • 행맨(Hangman) 은 컴퓨터가 정한 단어를 사용자가 한 글자씩 추측
#   하는 간단한 단어 맞히기 게임입니다. 제한된 회수 내에 단어를 맞
#   추면 성공이고 아니면 실패입니다.
# • 동작
#   • 사용자에게 제시할 단어를 어휘 리스트에서 선택한다.
#       • 예 hangman
#   • 단어의 글자 수 만큼 밑줄을 출력한다.
#       •_ _ _ _ _ _ _
#   • 사용자에게 글자를 입력하게 한다.
#       • 예: n 입력
#   • 글자가 단어에 있으면 그 위치에 출력한다.
#       • _ _ n _ _ _ n
#   • 단어에 없는 글자를 입력하면 ‘Nope!’ 이라고 출력하고 남은 횟수를 알려 준다.
#       • Nope! 3 trials left
#       • _ _ n _ _ _ n
#   • 제한된 횟수 내에 단어를 맞추면 “Good Job!”, 실패하면 “Fail!’ 이라고 출력하고 종료한다.
#   • 옵션 기능
#       • 사용자에게 게임을 계속 할 것이지 선택하도록 하기.
#       • 어휘 리스트에서 단어를 랜덤하게 선택하여 제시하기.



import random
# 추가로 사용한 함수 및 메서드
# 함수: all(), zip(), random.choice()
# 메서드: str.lower()


MAX_TRIALS = 5
words = (
    "family", "friend", "mother", "father", "baby", "man", "woman", "child",
    "home", "house", "school", "water", "food", "time", "day", "night", "money",
    "eat", "drink", "go", "come", "see", "have", "do", "work", "play",
    "good", "bad", "big", "small", "happy", "sad", "hot", "cold"
)
# words = ("good", "bad", "big") # 테스트용


while True:
    # 게임 시작 전 남은 횟수, 글자별 공개 여부, 입력 이력을 초기화
    word = random.choice(words)
    trials = MAX_TRIALS
    matched = [False] * len(word)
    used_letters = set()


    print("_ " * len(word))

    # 남은 횟수가 있고 모든 글자를 맞히지 못한 동안 반복(오답일 때만 남은 횟수를 차감)
    while trials > 0 and not all(matched):

        # --------------- 입력부 ---------------
        # 알파벳 입력
        guess = input("알파벳 입력: ")

        # 한 글자 입력 여부 검사
        if len(guess) != 1:
            print("입력 오류: 한 글자만 입력 가능합니다.")
            continue

        # 알파벳 입력 여부 검사
        if "a" <= guess <= "z" or "A" <= guess <= "Z":
            guess = guess.lower()
        else:
            print("입력 오류: 알파벳만 입력 가능합니다")
            continue

        # 중복 입력 여부 검사
        if guess in used_letters:
            print("입력 오류: 이미 입력한 알파벳입니다")
            continue
        # 입력 이력에 반영
        used_letters.add(guess)


        # --------------- 판정 및 출력 ---------------
        # 입력 글자 판정 및 결과 반영
        if guess in word:
            for i in range(len(word)):
                # 확정되지 않은 위치의 알파벳만 정답여부 대조
                if not matched[i] and word[i] == guess:
                    matched[i] = True
        else:
            trials -= 1
            # 단수형·복수형 처리
            plural_suffix = "s" if trials != 1 else ""
            print(f"Nope! {trials} trial{plural_suffix} left") # 남은 횟수 0인 경우도 출력함

        # 현재 단어 상태 출력(.join메서드는 제외하고 작성함)
        # 단어의 각 글자와 해당 위치의 정답 여부를 함께 순회
        # 공개된 글자는 출력하고, 나머지 위치는 밑줄로 표시
        for letter, is_matched in zip(word, matched): # 나름 파이썬인데 for문을 range로 반복하기 싫음. iterable로 하고 싶음.
            if is_matched:
                print(letter, end=" ")
            else:
                print("_", end=" ")
        print()


    # --------------- 해당 게임 결과 및 재실행 ---------------
    # 승패 판별
    if all(matched):
        print("Good Job!")
    else:
        print("Fail!")
        print(f"The answer was '{word}'.")

    # 재실행 여부 입력받기
    while True:
        re_start = input("다시 시작하시겠습니까? y/n: ").lower()
        if re_start == "y":
            break
        elif re_start == "n":
            print("행맨 게임 종료")
            break

    if re_start == "n":
        break