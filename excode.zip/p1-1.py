# 연습문제 1-1: 입/출력문
#
# • 사용자에게서 정수 두 개를 입력 받음
# • 다음과 같이 출력
#   1 + 2 = 3
#   1 – 2 = -1
#   1 x 2 = 2
#   1 / 2 = 0.5
# ▪ 숫자 입력은 input()을 한 번 사용과 두 번 사용으로 각각수행해 보시오
# ▪ 출력문의 포맷은 f스트링 방식과 format() 메쏘드방식으로 각각 해보시오



# [실행 구성]
# 첫 번째 반복: input() 1회 + f-string 출력
# 두 번째 반복: input() 2회 + format() 출력
for flag in (True, False):
    if flag:
        print("input 1번 사용")
        x, y = map(int, input("정수 2개를 공백으로 구분해서 입력: ").split())
    else:
        print("input 2번 사용")
        x = int(input('첫 번째 정수 입력: '))
        y = int(input('두 번째 정수 입력: '))
    print()

    if flag:
        print("f-string을 이용한 출력\n")
        # 괄호 안의 연속된 문자열들은 결합해 하나의 문자열로 처리
        print(
            f"{x} + {y} = {x + y}\n"
            f"{x} - {y} = {x - y}\n"
            f"{x} x {y} = {x * y}\n"
            f"{x} / {y} = {x / y:.2f}\n"
        )
    else:
        print("format()을 이용한 출력\n")
        # 괄호 안의 연속된 문자열들은 결합으로 처리. .format는 전체 문자열에 적용.
        print(
            "{} + {} = {}\n"
            "{} - {} = {}\n"
            "{} x {} = {}\n"
            "{} / {} = {:.2f}\n"
            .format(
                x, y, x + y,
                x, y, x - y,
                x, y, x * y,
                x, y, x / y
                )
        )
