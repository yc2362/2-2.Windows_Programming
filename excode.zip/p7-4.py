# 연습7-4 리스트 컴프리헨션1
#
# • 다음 리스트 words에서 문자열의 길이가 5 이상인 단어만 추출
# 하여 새로운 리스트를 리스트 컴프리헨션으로 생성해보시오.
#
#     words = ["tiger", "lion", "elephant", "cat", "horse"]
#
#     생성된 리스트
#     ['tiger', 'elephant', 'horse']



words = ["tiger", "lion", "elephant", "cat", "horse"]
words = [word for word in words if len(word) >= 5]
print(words)