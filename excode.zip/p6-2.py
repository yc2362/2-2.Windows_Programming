# 연습 6-2. 클래스 상속
#
# • figure.py을 모듈로 import
# • figure 모듈의 Polygon을 상속하여 정삼각형 클래스 “Triangle” 정의.
#     • 삼각형의 면적을 구하여 표시하는 getArea() 메쏘드 오버라이드
#     • 객체가 몇번째 생성된 것인지 알려주는 getSerial() 메쏘드 추가
#     • 삼각형을 그리는 draw() 메쏘드 추가
# • Triangle의 객체를 이용하여
#     • 한 변의 길이가 300인 정삼각형의 면적을 구하여 출력하시오
#     • 생성된 인스턴스가 몇 번째 객체인지 출력하시오
#     • 이 삼각형을 그리시오
#
# # line drawing using tutle module
# import turtle
# for step in range(self.sideNumber):
#     turtle.forward(self.sideLen)
#     turtle.right(360/self.sideNumber)
# input("Press ant key to stop")



import turtle

import figure


class Triangle(figure.Polygon):
    serial_count = 0

    def __init__(self):
        super().__init__(3)
        type(self).serial_count += 1
        self.serial = type(self).serial_count

    def getArea(self):
        return 3 ** (1 / 2) / 4 * self.sideLen ** 2

    def getSerial(self):
        return self.serial

    def draw(self):
        turtle.right(180)
        for _ in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)
        # input("Press ant key to stop\n")
        turtle.done()

    # --------------- 예쁘게 그리기 draw메서드 ---------------
    # def draw(self):
    #     import math
    #     # self.sideNumber = 12
    # # ------------------------------

    #     n = self.sideNumber
    #     L = self.sideLen
    #
    #     # 외접원의 반지름
    #     R = L / (2 * math.sin(math.pi / n))
    #
    #     if n % 2 == 1:  # 홀수각형
    #         x = 0
    #         y = R
    #         angle = -180 / n
    #
    #     else:           # 짝수각형
    #         x = -L / 2
    #         y = R * math.cos(math.pi / n)
    #         angle = 0
    #
    #     # 그리지 않고 시작 위치로 이동
    #     turtle.penup()
    #     turtle.goto(x, y)
    #     turtle.setheading(angle)
    #     turtle.pendown()
    #
    #     # 시계방향으로 정다각형 그리기
    #     for step in range(n):
    #         turtle.forward(L)
    #         turtle.right(360 / n)
    #     turtle.done()


t = Triangle()
sideLen = 300
t.setSideLen(sideLen)

while t.sideLen <= 0:
    sideLen = float(input("Enter side length : "))
    t.setSideLen(sideLen)

print(f"도형: {t.getShape()}")
print(f"넓이: {t.getArea()}")
print(f"오브젝트 생성 순서: {t.getSerial()}")
t.draw()