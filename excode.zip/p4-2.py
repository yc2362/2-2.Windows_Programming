# 문제 4-2
# • 사용자가 요청한 파일을 읽어서 공백을 제외한 글자수, 단어의
# 수, 그리고 라인의 수를 출력하는 출력하는 프로그램을 작성하
# 시오
# • 단어는 공백으로 분리된 문자열
# • 라인은 \n으로 분리된 문자열
# • 출력 형식
# characters : 230
# words : 56
# lines : 8
# • 파일이 없을 경우 예외처리를 하시오
# • FileNotFoundError 처리

MOOD = 1
# MOOD = 2

file_name = input("파일명 입력: ")
characters = words = lines = 0
try:
    with open(file_name, "r") as file:

         while line := file.readline():
             lines += 1
             words_list = line.split()
             words += len(words_list)


except FileNotFoundError:
    print("파일이 없습니다")

else:
    print(F"characters : {characters}\n",
        F"words : {words}\n",
        F"lines : {lines}",
        sep= ""
    )