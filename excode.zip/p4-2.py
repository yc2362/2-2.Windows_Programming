# 문제 4-2
#
# • 사용자가 요청한 파일을 읽어서 공백을 제외한 글자수, 단어의
#   수, 그리고 라인의 수를 출력하는 출력하는 프로그램을 작성하시오
#     • 단어는 공백으로 분리된 문자열
#     • 라인은 \n으로 분리된 문자열
#     • 출력 형식
#         characters : 230
#         words : 56
#         lines : 8
# • 파일이 없을 경우 예외처리를 하시오
#     • FileNotFoundError 처리



# 파일명 입력 및 집계 변수 초기화
file_name = input("파일명 입력: ")
characters = words = lines = 0

try:
    with open(file_name, "r") as file:
        # 파일을 한 줄씩 읽으며 글자·단어·라인 수 누적
         while line := file.readline():
             lines += 1
             words_list = line.split()
             words += len(words_list)
             characters += sum(len(word) for word in words_list)
# 요청한 파일이 존재하지 않는 경우 처리
except FileNotFoundError:
    print("파일이 없습니다")
# 파일을 정상적으로 읽은 경우 집계 결과 출력
else:
    print(
        f"characters : {characters}\n"
        f"words : {words}\n"
        f"lines : {lines}"
    )