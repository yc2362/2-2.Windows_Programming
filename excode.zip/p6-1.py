# 연습6-1 class 연습
# • 아래와 같은 파이썬 클래스 ‘Calc’를 정의하시오
# • 생성자는 두개의 정수 파라미터를 갖는다
# • 메쏘드 add(), sub()는 각각 두 정수의 합과 차를 계산하여 반환한다.
# • 메쏘드 getSerial()은 객체가 몇 번째 생성된 인스턴스인지를 반환한다
#
# 연습6-1. 클래스 연습
# • 생성된 클래스를 다음 코드로 테스트 하시오.
# class Calc:
# . . . # 클래스 코드
# a = 3
# b = 2
# calc1 = Calc(a, b)
# print(f'{a} + {b} = {calc1.add()}’) # '3 + 2 = 5' 출력
# print(f'{a} - {b} = {calc1.sub()}’) # ‘3 - 2 = 1' 출력
# calc2 = Calc(3, 4)
# print(f'{3} + {4} = {calc2.add()}')
# print(f'{3} + {4} = {calc2.sub()}')
# print(f'Serial of calc1: {calc1.getSerial()}’) # 1 출력
# print(f'Serial of calc2: {calc2.getSerial()}’) # 2 출력




class Calc:
    count_Serial = 0
    def __init__(self, a, b):
        self.a = a
        self.b = b
        type(self).count_Serial += 1
        self.Serial = type(self).count_Serial

    def add(self):
        return self.a + self.b

    def sub(self):
        return self.a - self.b

    def  getSerial(self):
        return self.Serial



a = 3
b = 2
calc1 = Calc(a, b)
print(f'{a} + {b} = {calc1.add()}')
print(f'{a} - {b} = {calc1.sub()}')

calc2 = Calc(3, 4)
print(f'{3} + {4} = {calc2.add()}')
print(f'{3} - {4} = {calc2.sub()}')

print(f'Serial of calc1: {calc1.getSerial()}')
print(f'Serial of calc2: {calc2.getSerial()}')