# 연습7-2 리스트 조작
#
# • 다음 작업을 순서대로 수행하시오.
#     1 빈 리스트 num 만들기
#     2. 리스트에 10, 20, 30 추가
#     3. 20과 30 사이에 40 추가
#     4. 마지막 요소 삭제하고 출력
#     6. 요소들의 합을 구하여 출력



num = []
num.extend([10, 20, 30])
# num.insert(num.index(30), 40)
num.insert(2, 40)
num.pop()
print(num)
num_sum = sum(num)
print(num_sum)