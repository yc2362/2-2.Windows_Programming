# 연습 6-3. 추상 메쏘드
#
# • Polygon 클래스의 getArea()메쏘드를 추상메쏘드로 정의하고
#   자식클래스에서 반드시 정의하도록 해보시오.
# • 추상메쏘드를 정의하지 않은 자식 클래스는 객체생성이 되지
#   않음을 확인해보시오
# • 추상클래스, 추상메쏘드를 정의하려면 abc모듈 사용
#     from abc import ABC, abstractmethod



import figure


class Rectangle(figure.Polygon):
    serial_count = 0

    def __init__(self):
        super().__init__(4)
        type(self).serial_count += 1
        self.serial = type(self).serial_count

    # def getArea(self):
    #     return self.sideLen ** 2

    def getSerial(self):
        return self.serial


try:
    r = Rectangle()
except TypeError as e:
    print(
        "Rectangle 클래스의 인스턴스 생성 실패!\n"
        "에러명: TypeError\n"
        f"에러 내용: {e}"
    )
except Exception as e:
    print(
        "Rectangle 클래스의 인스턴스 생성 실패!\n"
        f"에러명: {type(e).__name__}\n"
        f"에러 내용: {e}"
    )
else:
    print("Rectangle 클래스의 인스턴스 생성 성공!")
