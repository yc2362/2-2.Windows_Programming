# 연습 6-3. 추상 메쏘드
# • Polygon 클래스의 getArea()메쏘드를 추상메쏘드로 정의하고
# 자식클래스에서 반드시 정의하도록 해보시오.
# • 추상메쏘드를 정의하지 않은 자식 클래스는 객체생성이 되지
# 않음을 확인해보시오
# • 추상클래스, 추상메쏘드를 정의하려면 abc모듈 사용
# from abc import ABC, abstractmethod

import figure



class Rectangle(figure.Polygon):
    count_Serial = 0
    def __init__(self):
        super().__init__(4)
        type(self).count_Serial += 1
        self.Serial = type(self).count_Serial

    # def getArea(self):
    #     return self.sideLen ** 2

    def getSerial(self):
        return self.Serial


try:
    r = Rectangle()
except Exception as e:
    print(f"Rectangle클래스의 인스턴스 생성 실패!")
    print(f"에러명: {type(e).__name__}")

