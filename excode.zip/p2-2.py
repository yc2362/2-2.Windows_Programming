# 문제 2-2. 딕셔너리 연습
#
# 1. 명단 작성
#   • 프로그램이 시작하면 사용자로 부터 학생의 학번(id)과 이름(name)을 입력받는다.
#   • 딕셔너리에 “id:name” 으로 아이템을 추가한다.
#   • 사용자가 학번으로 0 혹은 이름으로 None 이라고 입력할때까지 반복한다.
#   • 만들어진 딕셔너리를 출력한다.
# 2. 학번으로 이름 출력하기
#   • 사용자에게 학번을 입력하도록 한다.
#   • 학번에 해당하는 이름을 출력한다.
#   • 학번이 없으면 “not found!”를 출력한다
# 3. 종료
#   • 사용자가 ‘quit’을 입력하면 종료한다



students_dictionary = {}

# --------------- 학번 및 이름 입력  ---------------
while True:
    # 학번 입력
    student_id = input("학번 입력(종료시 '0' 입력): ")

    # 학번이 10진수 문자로만 이루어졌는지 검사. .isdecimal()를 사용함
    if not student_id.isdecimal():
        print("숫자만 입력 가능합니다")
        continue

    # 종료입력 '0' 검사
    if student_id == "0":
        break

    # 중복 학번인 경우 덮어쓰기 여부 확인
    if student_id in students_dictionary:
        if input(f"{students_dictionary[student_id]}학생이 같은 학번입니다. "
                 f"덮어쓸까요?\n덮어쓰기 -> y, 취소 -> 아무키: ") != "y":
            continue

    # 이름 입력
    student_name = input("이름 입력(종료시 'None' 입력): ")

    # 종료입력 'None' 검사
    if student_name == "None":
        break

    # 학생 딕셔너리에 입력
    students_dictionary[student_id] = student_name
    print()

# 만들어진 딕셔너리를 출력
print(f"\n학생 딕셔너리\n{students_dictionary}", end ="\n\n")


# --------------- 학생 딕셔너리에서 학번으로 이름 검색 후 출력 ---------------
while True:
    # 검색 할 학번 입력
    student_id = input("학번을 입력하세요(종료시 'quit' 입력): ")

    # 종료 입력 'quit' 검사
    if student_id == "quit":
        break

    if student_id in students_dictionary:
        # 학번에 해당하는 이름 출력
        print(f"학생의 이름: {students_dictionary[student_id]}")
    else:
        # 등록되지 않은 학번인 경우
        print("not found!")