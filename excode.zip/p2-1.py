# 문제 2-1. 리스트 연습
#
# • 크기가 같은 두 리스트의 각 원소들을 곱하여 합을 구하시오.
#   • 리스트의 원소는 3개의 정수
#   • 리스트는 리터럴로 생성
# • 예
#   • 두 리스트 각각 [1, 0, 1], [1, 1, 2] 이라면
#   • 결과는 1*1 + 0*1 + 1*2 -> 3
# • 다음과 같이 출력하시오
#   • [1, 0, 1]* [1, 1, 2] = 3



list_1 = [1, 0, 1]
list_2 = [1, 1, 2]
inner_product = 0

print(f"리스트 1: {list_1}")
print(f"리스트 2: {list_2}")

# 리스트의 원소개수 동일여부 판별
if len(list_1) !=len(list_2):
    print("두 리스트의 원소 개수가 다릅니다.")

else:
    # 순회 하며 내적 계산
    for i in range(len(list_1)):
        inner_product += list_1[i] * list_2[i]

    print(f"{list_1}* {list_2} = {inner_product}")






#print(f"{list_1}* {list_2} = {sum(a*b for a, b in zip(list_1, list_2))}")
