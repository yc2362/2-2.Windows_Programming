# 문제5-2. 데코레이터 연습2
#
# • 주어진 인수에 따라 add(a, b)가 다음과 같이 동작하도록 수정하는
#   데코레이터 deco2_add(type)을 작성하시오
#     def deco2_add(type):
#     . . .
#     @deco2_add(type = “math”)
#     def add(a, b):
#         return a + b
#     print(add(2, 4)) # ‘2 + 4 = 6’ 출력
#     # @deco2_add(type = “word”)
#     # def add(a, b):
#     #    return a + b
#     # print(add(1, 2)) # ‘The sum of 1 and 2 is 3’ 출력



def deco2_add(type):
    def deco_add(func):
        if type == "math":
            def wrapper(a, b):
                result = func(a, b)
                return f"{a} + {b} = {result}"
        elif type == "word":
            def wrapper(a, b):
                result = func(a, b)
                return f"The sum of {a} and {b} is {result}"

        return wrapper

    return deco_add


@deco2_add(type="word")
def add(a, b):
    return a + b


print(add(2, 4))
print(add(1, 2))