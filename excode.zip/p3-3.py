# 문제 3-3
#
# • 문자열에서 모음의 개수를 반환하는 함수를 작성하시오.
#     • 함수명: count_vowel
#     • 인수: 문자열
#     • 반환값: 정수
# • 사용자로 부터 문자열을 입력 받아 모음의 개수를 출력하는 프로그램을 작성하시오
#     • count_vowel 함수 이용



# 문자열을 순회하면서 각 문자를 소문자로 변환하고 모음 여부를 검사
def count_vowel(text):
    vowel_count = 0
    for char in text:
        char = char.lower()

        # 영어 모음(a, e, i, o, u)이면 개수를 1 증가
        if char in "aeiou" :
            vowel_count += 1

    return vowel_count



# 테스트용 입력 예시 (결과 영어 모음 8개), (복사하여 사용)
#Hello123_World! AEIOU xyz-가나다라마바사 9876 @#$%

text = input("문자열 입력: ")
print(f"알파벳 모음개수: {count_vowel(text)}")
