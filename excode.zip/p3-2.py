# 문제 3-2
#
# • 원소가 정수로 구성된 리스트를 인수로 받아서 가장 작은 값(min)
#   과 큰 값(max)을 찾아 튜플로 반환하는 함수를 작성하시오.
#     • 함수명: min_max
#     • 인수: 정수 리스트
#     • 반환값: (min, max)
# • 사용자로 부터 정수들을 입력 받아 min 값과 max값을 출력하는
#   프로그램을 작성하시오
#     • min_max 함수 이용



# 테스트용 입력 예시(복사하여 사용)
# 123  sgfw  b e3q g 3e343 -45 34 54 5 --242 -0 0 12-32


# 정수 리스트를 순회하여 최솟값과 최댓값을 튜플로 반환
def min_max(int_list):
    # 첫 번째 원소로 최솟값과 최댓값을 초기화
    # 이후 두 번째 원소부터 비교하며 갱신
    min_value = max_value = int_list[0]

    for num in int_list[1:]:
        if min_value > num:
            min_value = num

        if max_value < num:
            max_value = num

    return min_value, max_value

while True:

    str_list = input("띄어쓰기로 구분하여 정수를 입력하시오\n").split()
    int_list = []
    for num in str_list:
        # 음수 부호가 있으면 부호를 제외한 부분이 10진 숫자인지 검사
        minus = 0(''
                  '')
        if num[0] == '-':
            minus = 1

        if num[minus:].isdecimal():
            int_list.append(int(num))

    # 유효한 정수가 없으면 재입력, 하나 이상 있으면 입력 종료
    if len(int_list) == 0:
        print("정수입력이 없습니다\n")
    else:
        break

print(f"입력된 정수: {int_list}\n")

min_value, max_value = min_max(int_list)

print(f"min: {min_value}\nmax: {max_value}")
