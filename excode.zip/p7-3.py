# 연습7-3 리스트 for … in
#
# • 다음 리스트에서 중복된 숫자를 제거하시오.
#     numbers = [1, 2, 2, 5, 3, 4, 3, 5, 1, 6]
#     결과 => [1, 2, 5, 3, 4, 6]
#
# • 힌트
#     • 리스트 순환 -> for … in 이용
#     • 요소확인 -> in 혹은 not in 이용



numbers = [1, 2, 2, 5, 3, 4, 3, 5, 1, 6]

# for문 일반형
unique_numbers = []
for element in numbers:
    if element not in unique_numbers:
        unique_numbers.append(element)
print(unique_numbers)