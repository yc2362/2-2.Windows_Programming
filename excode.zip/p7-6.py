# 연습7-6 딕셔너리 조작
#
# • 딕셔너리 students에 다음 작업을 수행하시오
#     • 과목이 history, 점수가 90인 아이템을 딕셔너리에 추가
#     • 과목이 math인 아이템을 딕셔너리에서 제거
#     • 과목이 science인 아이템의 점수를 100으로 수정
#     • histoy와 science 점수의 평균을 구하여
#     “Kim’s average score is 000” 출력
#
#     students = {
#         "name": "Kim",
#         "math": 80,
#         "science": 90
#     }




students = {
    "name": "Kim",
    "math": 80,
    "science": 90
}

students["history"] = 90
students.pop("math")
students["science"] = 100
average = (students["history"] + students["science"]) / 2
print(f"{students["name"]}’s average score is {average}")