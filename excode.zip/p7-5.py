# 연습7-5 리스트 컴프리헨션2
#
# • 다음 문자열에서 모음(a, e, i, o, u)을 제외한 문자들을 요소로
#   가진 리스트를 리스트컴프리헨션으로 생성하시오.
#     text = "window programm"
#     생성된 리스트
#     ['w','n','d','w',' ','p','r','g','r','m','m']



text = "window programm"
list_char = [char for char in text if char not in "aeiou" ]
print(list_char)