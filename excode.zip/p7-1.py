# 연습7-1 문자열/튜플 슬라이싱
#
# • 다음 코드의 출력 결과는?
#     str = "WindowProgramming"
#
#     print(str[1:4])
#     print(str[9:])
#     print(str[2:8:2])
#     print(str[-1:10:-1])
#
# • 위의 문자열 str을 튜플로 변환하여 동일한 슬라이싱 작업을 수행해 보시오
#     • tuple() 생성자를 활용하시오



# 7-1-1 출력결과
print("7-1-1번 다음 코드의 출력 결과는?(주석참조)")
print("ind") # 1번 인덱스 'i' 부터 4번 인덱스 'o' 직전까지 슬라이싱되어 반환
print("gramming") # 9번 인덱스 'g' 부터 마지막 인덱스 'g' 까지 슬라이싱되어 반환
print("noP") # 2번 인덱스 'n' 부터 8번 인덱스 'o' 까지 두칸씩 이동하며 슬라이싱되어 반환
print("gnimma") # 마지막 인덱스 'g' 부터 10번 인덱스 'r' 직전까지 역순으로 슬라이싱되어 반환


# 7-1-2 출력결과
str = tuple("WindowProgramming")

# str를 슬라이싱 한 결과에서 각각의 인덱스를 인수로 같는 튜플가 같은 형태로 생성
print(str[1:4])
print(str[9:])
print(str[2:8:2])
print(str[-1:10:-1])